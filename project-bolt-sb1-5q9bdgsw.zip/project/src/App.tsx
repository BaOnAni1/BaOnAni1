import React, { useState } from 'react';
import { LoginForm } from './components/LoginForm';
import { NetflixLogo } from './components/NetflixLogo';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleLogin = (email: string, password: string) => {
    // In a real app, you would validate credentials here
    console.log('Login attempt:', { email, password });
    setIsLoggedIn(true);
  };

  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-black text-white">
        <header className="bg-black shadow-lg">
          <div className="container mx-auto px-4 py-6">
            <NetflixLogo />
          </div>
        </header>
        <main className="container mx-auto px-4 py-8">
          <h2 className="text-3xl font-bold mb-6">Popular on Netflix</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {/* Movie cards */}
            {[1, 2, 3, 4, 5, 6, 8].map((i) => (
              <div key={i} className="relative group">
                <img
                  src={`https://source.unsplash.com/random/800x450?movie,${i}`}
                  alt="Movie thumbnail"
                  className="w-full rounded-md transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                  <h3 className="text-white font-semibold">Movie Title {i}</h3>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>
    );
  }

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url("https://source.unsplash.com/random/1920x1080?movie,cinema")'
      }}
    >
      <div className="w-full max-w-md px-6 py-8 bg-black/80 rounded-lg shadow-xl">
        <div className="mb-8 flex justify-center">
          <NetflixLogo />
        </div>
        <LoginForm onSubmit={handleLogin} />
        <p className="mt-6 text-center text-sm text-gray-400">
          New to Netflix?{' '}
          <a href="#" className="text-white hover:underline">
            Sign up now
          </a>
        </p>
      </div>
    </div>
  );
}

export default App;