import { Play } from 'lucide-react';

export function NetflixLogo() {
  return (
    <div className="flex items-center text-red-600 font-bold text-4xl">
      <Play className="w-8 h-8 mr-2" />
      <span>NETFLIX</span>
    </div>
  );
}